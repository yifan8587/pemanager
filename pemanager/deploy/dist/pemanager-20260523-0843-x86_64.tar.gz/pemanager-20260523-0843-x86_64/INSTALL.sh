#!/usr/bin/env bash
# =============================================================================
# PE Manager 离线包 一键安装入口
#
# 使用：
#   sudo bash INSTALL.sh                                # 在线 + 默认 HTTP
#   sudo bash INSTALL.sh --ssl-domain pe.example.com    # 启用 Let's Encrypt
#   sudo bash INSTALL.sh --ssl-ip [1.2.3.4]             # 自签名 SSL
#   sudo bash INSTALL.sh --offline                      # 完全离线（要求打包时 --with-debs/--with-wheels/--with-frontend）
# =============================================================================
set -Eeuo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

OFFLINE=0
PASS_ARGS=()
while [[ $# -gt 0 ]]; do
    case "$1" in
        --offline) OFFLINE=1 ;;
        *)         PASS_ARGS+=("$1") ;;
    esac
    shift
done

[[ $EUID -eq 0 ]] || { echo "请以 root 运行：sudo bash INSTALL.sh ..."; exit 1; }

cat "${HERE}/VERSION" 2>/dev/null || true
echo

# 1) 环境检查 / 安装
if [[ $OFFLINE -eq 1 && -d "${HERE}/deploy/debs" ]]; then
    bash "${HERE}/deploy/setup.sh" --yes --offline "${HERE}/deploy/debs"
else
    bash "${HERE}/deploy/setup.sh" --yes
fi

# 2) 一键部署
DEPLOY_ARGS=(--src "${HERE}" --skip-setup-check)

# 离线模式：让 deploy.sh 用本地 wheelhouse 优先（设置 PIP_FIND_LINKS）
if [[ $OFFLINE -eq 1 && -d "${HERE}/deploy/wheelhouse" ]]; then
    export PIP_FIND_LINKS="${HERE}/deploy/wheelhouse"
    export PIP_NO_INDEX=1
    echo "[INSTALL] 已设置 PIP_FIND_LINKS=${PIP_FIND_LINKS} + PIP_NO_INDEX=1"
fi
# 离线 + 已预 build 前端：把 dist 提前拷到 /opt 安装路径前需要 deploy.sh 不再 build；
# 这里通过环境变量告诉 deploy.sh 是否要跳过 npm build
if [[ $OFFLINE -eq 1 && -d "${HERE}/frontend/dist" ]]; then
    export PEMANAGER_SKIP_FRONTEND_BUILD=1
    echo "[INSTALL] 检测到已预 build 的 frontend/dist；deploy.sh 将跳过 npm build"
fi

bash "${HERE}/deploy/deploy.sh" "${DEPLOY_ARGS[@]}" "${PASS_ARGS[@]}"
