"""账号与 API 令牌模型。

- `User` 继承 `AbstractUser`：增加 `role`、`customer`、`phone` 等字段；
  - `role=admin`：系统管理员，所有功能可用；
  - `role=operator`：运维（保留，与 admin 同等读写但默认不创建超级用户标记）；
  - `role=customer`：客户账号，只可看自己客户的接口/路由/带宽/流量图。
- `APIToken`：长期 API 令牌，由 ViewSet 创建/吊销；存哈希，明文只在创建时一次性返回。
- `LoginAttempt`：登录尝试审计（可选，最简化）。
"""
from __future__ import annotations

import hashlib
import secrets
import uuid
from datetime import timedelta

from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils import timezone

from resourcemanage.models import ResourceCustomer


class User(AbstractUser):
    """PE Manager 用户：扩展 Django AbstractUser，增加角色与客户绑定。"""

    class Role(models.TextChoices):
        ADMIN = 'admin', '系统管理员'
        OPERATOR = 'operator', '运维人员'
        CUSTOMER = 'customer', '客户账号'

    role = models.CharField(
        '角色',
        max_length=16,
        choices=Role.choices,
        default=Role.CUSTOMER,
        db_index=True,
    )
    customer = models.ForeignKey(
        ResourceCustomer,
        verbose_name='绑定客户',
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='users',
        help_text='角色为「客户账号」时必填；管理员可空',
    )
    phone = models.CharField('手机', max_length=32, blank=True)
    remark = models.CharField('备注', max_length=512, blank=True)

    class Meta(AbstractUser.Meta):
        verbose_name = 'PE Manager 用户'
        verbose_name_plural = verbose_name

    @property
    def is_admin_role(self) -> bool:
        return self.role == self.Role.ADMIN or self.is_superuser

    @property
    def is_operator_role(self) -> bool:
        return self.role in (self.Role.ADMIN, self.Role.OPERATOR) or self.is_superuser

    @property
    def is_customer_role(self) -> bool:
        return self.role == self.Role.CUSTOMER and not self.is_superuser


def _hash_token(secret: str) -> str:
    """SHA-256 哈希。短令牌随机性足够（≥40 bytes）即可，不必再加 salt。"""
    return hashlib.sha256(secret.encode('utf-8')).hexdigest()


class APIToken(models.Model):
    """长期 API 令牌（替代 / 补充 JWT 短期 access）。

    使用方式：
      Authorization: Bearer pem_<prefix>.<secret>
    服务端用 `prefix` 索引令牌，再用 `secret` SHA-256 后与 `key_hash` 校验。
    """

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(
        'accountmanage.User',
        on_delete=models.CASCADE,
        related_name='api_tokens',
        verbose_name='所属用户',
    )
    name = models.CharField('名称', max_length=128)
    prefix = models.CharField('前缀', max_length=16, unique=True, db_index=True)
    key_hash = models.CharField('密钥 SHA-256', max_length=64)
    scope = models.CharField(
        '作用域', max_length=32, default='full',
        help_text='保留扩展字段；默认 full 表示与所属用户同权',
    )
    last_used_at = models.DateTimeField('最近使用', null=True, blank=True)
    last_used_ip = models.GenericIPAddressField('最近来源 IP', null=True, blank=True)
    expires_at = models.DateTimeField('过期时间', null=True, blank=True, db_index=True)
    revoked = models.BooleanField('已吊销', default=False, db_index=True)
    created_at = models.DateTimeField('创建时间', auto_now_add=True)
    updated_at = models.DateTimeField('更新时间', auto_now=True)

    class Meta:
        verbose_name = 'API 令牌'
        verbose_name_plural = verbose_name
        ordering = ['-created_at']

    def __str__(self) -> str:
        return f'{self.user.username}/{self.name} ({self.prefix})'

    @staticmethod
    def generate(user: 'User', name: str, *, ttl_days: int | None = None, scope: str = 'full') -> tuple['APIToken', str]:
        """生成新令牌，返回 (token_obj, plaintext_full)。明文只在创建时返回一次。"""
        prefix = 'pem_' + secrets.token_urlsafe(6)
        secret = secrets.token_urlsafe(40)
        plaintext = f'{prefix}.{secret}'
        obj = APIToken.objects.create(
            user=user,
            name=name[:128] or 'token',
            prefix=prefix,
            key_hash=_hash_token(secret),
            scope=scope,
            expires_at=(timezone.now() + timedelta(days=ttl_days)) if ttl_days else None,
        )
        return obj, plaintext

    def verify_secret(self, secret: str) -> bool:
        return secrets.compare_digest(self.key_hash, _hash_token(secret))

    @property
    def is_expired(self) -> bool:
        return bool(self.expires_at and self.expires_at <= timezone.now())

    def mark_used(self, ip: str | None = None) -> None:
        APIToken.objects.filter(pk=self.pk).update(
            last_used_at=timezone.now(),
            last_used_ip=(ip or None),
        )


class LoginAttempt(models.Model):
    """登录尝试审计：成功/失败均落库，便于排查暴力破解。"""

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    username = models.CharField('用户名', max_length=128, db_index=True)
    success = models.BooleanField('成功', default=False, db_index=True)
    ip = models.GenericIPAddressField('来源 IP', null=True, blank=True)
    user_agent = models.CharField('UA', max_length=256, blank=True)
    error = models.CharField('错误', max_length=256, blank=True)
    created_at = models.DateTimeField('时间', auto_now_add=True, db_index=True)

    class Meta:
        verbose_name = '登录尝试'
        verbose_name_plural = verbose_name
        ordering = ['-created_at']
