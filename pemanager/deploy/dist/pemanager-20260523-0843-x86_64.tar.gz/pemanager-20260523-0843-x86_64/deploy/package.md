# package.md — 制作可分发的离线部署包

`deploy/package.sh` 可以把整个项目（源码 + 部署脚本 + 可选的依赖资源）打成一个 tar.gz 压缩包，
**在其他系统中只需一行 `tar xzf ... && cd ... && sudo bash INSTALL.sh` 即可安装**。

支持四档"备货"，按部署目标的网络环境组合：

| 选项 | 包含内容 | 包大小（估） | 适用场景 |
|---|---|---|---|
| 仅源码 | 源码 + `deploy/` | ~5 MB | 目标机能上 PyPI / npm / apt |
| `--with-frontend` | 源码 + 预 build 的 `frontend/dist/` | ~10 MB | 目标机无 Node 工具链 |
| `--with-wheels` | 源码 + `deploy/wheelhouse/`（全部 Python wheels） | ~40 MB | 目标机无法访问 PyPI |
| `--with-debs` | 源码 + `deploy/debs/`（所有系统 .deb） | ~250 MB | 目标机无法 apt update |
| 四项全开（完全离线） | 全部 | ~300 MB | 内网 / 受限服务器 |

---

## 1. 在能联网的机器上打包

```bash
cd /root/pemanager

# A) 最小包：仅源码 + 部署脚本
sudo bash deploy/package.sh

# B) 含前端 dist（目标机不再 npm install）
sudo bash deploy/package.sh --with-frontend

# C) 完全离线包（推荐用于内网批量部署）
sudo bash deploy/package.sh --with-debs --with-wheels --with-frontend

# 自定义版本号 / 输出路径
sudo bash deploy/package.sh --version v1.0.0 -o /tmp/pemanager-v1.0.0.tar.gz
```

产物默认在 `deploy/dist/pemanager-<version>-<arch>.tar.gz`，并打印 SHA256 校验值：

```
==== 制作完成 ====
压缩包: /root/pemanager/deploy/dist/pemanager-20260523-1620-abc1234-x86_64.tar.gz
大小  : 287M
SHA256: a1b2c3...
```

---

## 2. 离线包内部结构

```
pemanager-<ver>/
├── INSTALL.sh                  # 一键入口（调用 setup.sh + deploy.sh）
├── README.txt                  # 离线包简介 + 命令示例
├── VERSION                     # 打包时间 / 版本号 / 是否含 wheels/debs/dist
├── backend/                    # Django 源码
├── frontend/                   # 前端源码（如 --with-frontend，包含 dist/）
├── requirements.txt
└── deploy/
    ├── setup.sh / setup.md
    ├── deploy.sh / deploy.md
    ├── ssl-setup.sh / ssl.md
    ├── package.sh / package.md
    ├── API.md
    ├── templates/              # nginx / systemd / env / sudoers 模板
    ├── debs/                   # 仅 --with-debs：系统依赖 .deb
    └── wheelhouse/             # 仅 --with-wheels：Python wheel 集合
```

---

## 3. 在目标机解压安装

### 3.1 在线安装（包仅源码 / 不带 wheels）

```bash
tar xzf pemanager-<ver>.tar.gz
cd pemanager-<ver>
sudo bash INSTALL.sh                                         # HTTP
sudo bash INSTALL.sh --ssl-domain pe.example.com             # HTTPS 域名
sudo bash INSTALL.sh --ssl-ip                                # HTTPS 自签名 IP
```

### 3.2 完全离线安装（包带 debs + wheels + frontend/dist）

```bash
tar xzf pemanager-<ver>.tar.gz
cd pemanager-<ver>
sudo bash INSTALL.sh --offline
sudo bash INSTALL.sh --offline --ssl-ip                      # 内网自签名
sudo bash INSTALL.sh --offline --ssl-domain pe.example.com   # 系统离线 + Let's Encrypt 在线
```

`--offline` 模式行为：
1. **apt**：从 `deploy/debs/` 中 `dpkg -i` 安装所有 `.deb`，并 `apt-get -f install` 解决依赖
2. **pip**：自动设置 `PIP_FIND_LINKS=deploy/wheelhouse PIP_NO_INDEX=1`，从本地 wheel 安装
3. **npm**：若包内有 `frontend/dist/`，设置 `PEMANAGER_SKIP_FRONTEND_BUILD=1`，`deploy.sh` 跳过 `npm install/build`
4. 其余流程与 `deploy.sh` 完全一致（systemd unit / nginx / migrate / collectstatic / 健康检查）

> `--ssl-domain` 模式仍需访问 Let's Encrypt ACME 服务器；**纯离线**请配 `--ssl-ip`（自签名）。

---

## 4. 校验与签名

打包脚本自动打印 SHA256；分发渠道（FTP / 网盘 / OSS）请同时附带校验文件：

```bash
sha256sum pemanager-<ver>.tar.gz > pemanager-<ver>.tar.gz.sha256
# 目标机
sha256sum -c pemanager-<ver>.tar.gz.sha256
```

如需 GPG 签名（建议公共下载场景）：

```bash
gpg --detach-sign --armor pemanager-<ver>.tar.gz
# 产出 pemanager-<ver>.tar.gz.asc
```

---

## 5. 常见问题

### 5.1 `--with-debs` 阶段提示 `apt-get download` 报错
确认打包机已 `apt update`；某些子包（如 NodeSource 的 `nodejs`）需要先 `add-apt-repository` 加源后才能下载。
对应步骤可改为：

```bash
# 先在打包机装好 NodeSource 源（setup.sh 已做），再跑：
sudo bash deploy/package.sh --with-debs
```

### 5.2 `--with-wheels` 在 x86_64 上打的包能不能装到 aarch64 机器
**不行**。Python wheel 含本地编译产物（如 `cryptography`、`PyYAML` 的 C 扩展），架构必须匹配。
打包文件名里已经带 `<arch>`（如 `pemanager-20260523-1620-x86_64.tar.gz`），请分别打两个包。

### 5.3 目标机 Python 版本与打包机不一致
wheelhouse 是为打包机的 Python ABI 准备的；建议：
- 打包机和目标机用同版本 Python（如都 3.12）
- 或加 `pip download --python-version 3.12 --platform manylinux2014_x86_64 --only-binary=:all:` 显式限定

### 5.4 INSTALL.sh 在 RHEL/CentOS 上跑不动
当前 `setup.sh` / `deploy.sh` 只支持 apt 系。RHEL/CentOS 请按 [setup.md](./setup.md) 中的"软件包对照表"手工补依赖后，直接跑：

```bash
sudo bash deploy/deploy.sh --skip-setup-check
```

### 5.5 想去掉某些资源以瘦身
`package.sh` 默认只把"明确加 `--with-*` 的资源"打入；不带选项时包内不含 wheels / debs / node_modules。

### 5.6 多次打包导致 `dist/` 越堆越多
```bash
sudo rm -rf deploy/dist/* && sudo bash deploy/package.sh ...
```

---

## 6. CI / 自动化

GitHub Actions 示例（每次推 tag 时打 release）：

```yaml
- name: Build pemanager release tarball
  run: |
    sudo bash deploy/setup.sh --yes
    sudo bash deploy/package.sh --with-frontend --with-wheels \
        --version "${GITHUB_REF_NAME}" \
        --output "deploy/dist/pemanager-${GITHUB_REF_NAME}.tar.gz"

- name: Upload artifact
  uses: actions/upload-artifact@v4
  with:
    name: pemanager-${{ github.ref_name }}
    path: deploy/dist/pemanager-${{ github.ref_name }}.tar.gz
```

---

## 7. 端到端示例

### 7.1 完全离线交付一台新机

打包机（能上网）：

```bash
sudo bash deploy/setup.sh --yes
sudo bash deploy/package.sh --with-debs --with-wheels --with-frontend
ls -lh deploy/dist/pemanager-*.tar.gz
```

把 `pemanager-*.tar.gz` 通过任意手段拷到目标机；目标机：

```bash
tar xzf pemanager-*.tar.gz && cd pemanager-*
sudo bash INSTALL.sh --offline --ssl-ip 10.0.0.10
```

10 分钟左右完成（具体取决于硬件），随后即可访问 `https://10.0.0.10/`，
默认账号 `admin / admin123`。
