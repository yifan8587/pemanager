#!/usr/bin/env bash
# =============================================================================
# PE Manager — 制作可分发的离线部署包
#
# 产出：deploy/dist/pemanager-<version>-<arch>.tar.gz
#       内含：完整源码 + deploy/ + INSTALL.sh + 可选离线 pip wheels / npm vendor
#
# 用途：在受限网络的目标机器上「解压即装」：
#         tar xzf pemanager-<ver>.tar.gz
#         cd pemanager-<ver>
#         sudo bash INSTALL.sh                                  # 在线 / 默认
#         sudo bash INSTALL.sh --ssl-domain pe.example.com      # 部署完毕直接启用 HTTPS
#         sudo bash INSTALL.sh --ssl-ip                         # 自签名 SSL
#         sudo bash INSTALL.sh --offline                        # 完全离线（要求 --with-wheels）
#
# 选项：
#   --with-wheels      预先 pip download 全部 Python 依赖（含 gunicorn）到包中
#   --with-npm         预先 npm install 并把 node_modules 一起带上（跳过目标机 npm install）
#   --with-frontend    预先在本机 npm run build，把 frontend/dist/ 一起带上（目标机不再 build）
#   --with-debs        预先 apt download 所有系统依赖 .deb（适合完全离线部署）
#   --version <str>    自定义版本号（默认 YYYYMMDD-HHMM-<git-short> / 无 git 时去掉后缀）
#   --output <file>    自定义输出文件名
# =============================================================================

set -Eeuo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[0;33m'; BLUE='\033[0;34m'; NC='\033[0m'
log()  { printf "${BLUE}[pkg]${NC} %s\n" "$*"; }
ok()   { printf "${GREEN}[ ok ]${NC} %s\n" "$*"; }
warn() { printf "${YELLOW}[warn]${NC} %s\n" "$*"; }
err()  { printf "${RED}[ err]${NC} %s\n" "$*" >&2; }
trap 'err "脚本在第 ${LINENO} 行失败，退出码 $?"' ERR

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

WITH_WHEELS=0
WITH_NPM=0
WITH_FRONTEND=0
WITH_DEBS=0
VERSION=""
OUTPUT=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        --with-wheels)   WITH_WHEELS=1 ;;
        --with-npm)      WITH_NPM=1 ;;
        --with-frontend) WITH_FRONTEND=1 ;;
        --with-debs)     WITH_DEBS=1 ;;
        --version)       VERSION="$2"; shift ;;
        --output|-o)     OUTPUT="$2";  shift ;;
        -h|--help) grep -E '^# (产出|用途|选项)' "$0" | sed 's/^# //'; exit 0 ;;
        *) err "未知参数: $1"; exit 2 ;;
    esac
    shift
done

# ----- 版本号 -----
if [[ -z "$VERSION" ]]; then
    GIT_SHORT=""
    if command -v git >/dev/null 2>&1 && [[ -d "${SRC_ROOT}/.git" ]]; then
        GIT_SHORT="-$(git -C "${SRC_ROOT}" rev-parse --short HEAD 2>/dev/null || echo)"
    fi
    VERSION="$(date +%Y%m%d-%H%M)${GIT_SHORT}"
fi
ARCH="$(uname -m)"
DIST_DIR="${SCRIPT_DIR}/dist"
mkdir -p "${DIST_DIR}"
STAGE="$(mktemp -d -t pemanager-pkg-XXXXXX)"
PKG_NAME="pemanager-${VERSION}-${ARCH}"
PKG_DIR="${STAGE}/${PKG_NAME}"
mkdir -p "${PKG_DIR}"

log "源码根：${SRC_ROOT}"
log "暂存：  ${PKG_DIR}"
log "版本：  ${VERSION} / ${ARCH}"

# ----- 1) rsync 源码（排除大件） -----
log "[1/7] 同步源码到暂存目录"
RSYNC_EXCL=(
    --exclude '/venv/' --exclude '/.venv/'
    --exclude '/frontend/node_modules/'
    --exclude '/backend/db.sqlite3'
    --exclude '/backend/db.sqlite3.*'      # 排除所有 db 备份
    --exclude '*.sqlite3'                  # 排除任意目录下的 sqlite db
    --exclude '*.sqlite3.bak.*'
    --exclude '/backend/staticfiles/'
    --exclude '__pycache__'
    --exclude '/deploy/dist/'
    --exclude '/.git/'
    --exclude '*.pyc'
    --exclude '*.swp'
    --exclude '.DS_Store'
    --exclude '.env' --exclude '.env.*'    # 防止把开发期 env 带入
    --exclude '*.pem'  --exclude '*.key'   # 防止把本机证书带入
    --exclude '/var/' --exclude '/tmp/'
)
# frontend/dist 若选择 --with-frontend 则保留，否则排除
if [[ $WITH_FRONTEND -ne 1 ]]; then
    RSYNC_EXCL+=(--exclude '/frontend/dist/')
fi
rsync -a "${RSYNC_EXCL[@]}" "${SRC_ROOT}/" "${PKG_DIR}/"
ok "源码同步完成"

# ----- 2) 可选：预下载 Python wheels -----
if [[ $WITH_WHEELS -eq 1 ]]; then
    log "[2/7] 预下载 Python wheels 到 deploy/wheelhouse/"
    REQ="${PKG_DIR}/backend/requirements.txt"
    [[ -f "$REQ" ]] || REQ="${PKG_DIR}/requirements.txt"
    if [[ ! -f "$REQ" ]]; then
        err "未找到 requirements.txt"; exit 1
    fi
    WHEELS_DIR="${PKG_DIR}/deploy/wheelhouse"
    mkdir -p "${WHEELS_DIR}"
    pip3 download -r "$REQ" -d "${WHEELS_DIR}" --no-cache-dir
    # gunicorn 单独下，确保离线也能装
    pip3 download "gunicorn>=21.2" -d "${WHEELS_DIR}" --no-cache-dir
    ok "wheels 数量：$(ls -1 ${WHEELS_DIR} | wc -l)"
else
    log "[2/7] 跳过 wheels 下载（--with-wheels 启用后可一并打包）"
fi

# ----- 3) 可选：预 npm install / build -----
if [[ $WITH_FRONTEND -eq 1 ]]; then
    log "[3/7] 在本机 npm install + npm run build（产物已随 rsync 一起带入）"
    pushd "${PKG_DIR}/frontend" >/dev/null
    if [[ ! -d node_modules ]]; then
        if [[ -f package-lock.json ]]; then npm ci --no-audit --no-fund; else npm install --no-audit --no-fund; fi
    fi
    npm run build
    popd >/dev/null
    ok "前端 dist 已就绪：frontend/dist/"
elif [[ $WITH_NPM -eq 1 ]]; then
    log "[3/7] 预安装 npm 依赖（带 node_modules 一起打包）"
    pushd "${PKG_DIR}/frontend" >/dev/null
    if [[ -f package-lock.json ]]; then npm ci --no-audit --no-fund; else npm install --no-audit --no-fund; fi
    popd >/dev/null
    ok "node_modules 已包含到包内"
else
    log "[3/7] 跳过前端预 build；目标机将在线 npm install + npm run build"
fi

# ----- 4) 可选：预下载 apt .deb -----
if [[ $WITH_DEBS -eq 1 ]]; then
    log "[4/7] 预下载 apt .deb 到 deploy/debs/"
    DEBS_DIR="${PKG_DIR}/deploy/debs"
    mkdir -p "${DEBS_DIR}"
    # 与 setup.sh 中的 PKG_LIST 对齐
    APT_PKGS=(
        python3 python3-venv python3-pip build-essential libffi-dev libssl-dev
        nginx netplan.io wireguard-tools iproute2 iptables nftables
        mtr-tiny iputils-ping traceroute openssl curl sqlite3 rsync
        ca-certificates logrotate certbot python3-certbot-nginx tar gzip
    )
    APT_LIST_OPT="--print-uris"
    pushd "${DEBS_DIR}" >/dev/null
    apt-get download "${APT_PKGS[@]}" 2>/dev/null || warn "apt-get download 部分包失败，可在目标机补"
    popd >/dev/null
    ok "deb 数量：$(ls -1 ${DEBS_DIR} 2>/dev/null | wc -l)"
else
    log "[4/7] 跳过 deb 下载（--with-debs 启用后可一并打包）"
fi

# ----- 5) 写入 VERSION + INSTALL.sh -----
log "[5/7] 生成 VERSION + INSTALL.sh"
cat >"${PKG_DIR}/VERSION" <<EOF
PE Manager 离线部署包
打包时间：$(date '+%F %T %Z')
打包主机：$(hostname)
版本号：${VERSION}
架构：${ARCH}
含 wheels：${WITH_WHEELS}
含 node_modules：${WITH_NPM}
含 frontend/dist：${WITH_FRONTEND}
含 .deb：${WITH_DEBS}
EOF

cat >"${PKG_DIR}/INSTALL.sh" <<'INSTALL_EOF'
#!/usr/bin/env bash
# =============================================================================
# PE Manager 离线包 一键安装入口
#
# 使用：
#   sudo bash INSTALL.sh                                # 在线 + 默认 HTTP
#   sudo bash INSTALL.sh --ssl-domain pe.example.com    # 启用 Let's Encrypt
#   sudo bash INSTALL.sh --ssl-ip [1.2.3.4]             # 自签名 SSL
#   sudo bash INSTALL.sh --offline                      # 完全离线（要求打包时 --with-debs/--with-wheels/--with-frontend）
# =============================================================================
set -Eeuo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

OFFLINE=0
PASS_ARGS=()
while [[ $# -gt 0 ]]; do
    case "$1" in
        --offline) OFFLINE=1 ;;
        *)         PASS_ARGS+=("$1") ;;
    esac
    shift
done

[[ $EUID -eq 0 ]] || { echo "请以 root 运行：sudo bash INSTALL.sh ..."; exit 1; }

cat "${HERE}/VERSION" 2>/dev/null || true
echo

# 1) 环境检查 / 安装
if [[ $OFFLINE -eq 1 && -d "${HERE}/deploy/debs" ]]; then
    bash "${HERE}/deploy/setup.sh" --yes --offline "${HERE}/deploy/debs"
else
    bash "${HERE}/deploy/setup.sh" --yes
fi

# 2) 一键部署
DEPLOY_ARGS=(--src "${HERE}" --skip-setup-check)

# 离线模式：让 deploy.sh 用本地 wheelhouse 优先（设置 PIP_FIND_LINKS）
if [[ $OFFLINE -eq 1 && -d "${HERE}/deploy/wheelhouse" ]]; then
    export PIP_FIND_LINKS="${HERE}/deploy/wheelhouse"
    export PIP_NO_INDEX=1
    echo "[INSTALL] 已设置 PIP_FIND_LINKS=${PIP_FIND_LINKS} + PIP_NO_INDEX=1"
fi
# 离线 + 已预 build 前端：把 dist 提前拷到 /opt 安装路径前需要 deploy.sh 不再 build；
# 这里通过环境变量告诉 deploy.sh 是否要跳过 npm build
if [[ $OFFLINE -eq 1 && -d "${HERE}/frontend/dist" ]]; then
    export PEMANAGER_SKIP_FRONTEND_BUILD=1
    echo "[INSTALL] 检测到已预 build 的 frontend/dist；deploy.sh 将跳过 npm build"
fi

bash "${HERE}/deploy/deploy.sh" "${DEPLOY_ARGS[@]}" "${PASS_ARGS[@]}"
INSTALL_EOF
chmod 0755 "${PKG_DIR}/INSTALL.sh"
ok "INSTALL.sh 已写入"

# ----- 6) 写 README（包内） -----
cat >"${PKG_DIR}/README.txt" <<EOF
PE Manager 离线部署包
=====================

快速开始：
    tar xzf ${PKG_NAME}.tar.gz
    cd ${PKG_NAME}
    sudo bash INSTALL.sh                                  # HTTP 一键部署
    sudo bash INSTALL.sh --ssl-domain pe.example.com      # 带 Let's Encrypt 证书
    sudo bash INSTALL.sh --ssl-ip                         # 自签名（IP 部署）
    sudo bash INSTALL.sh --offline                        # 完全离线（需打包时 --with-debs/--with-wheels/--with-frontend）

详细文档：
    deploy/setup.md    - 环境检查
    deploy/deploy.md   - 部署与升级
    deploy/ssl.md      - HTTPS 启用
    deploy/package.md  - 打包说明
    deploy/API.md      - API 文档

部署后默认登录：
    URL：   http(s)://<主机/域名>/
    账号：  admin / admin123（首次登录请改密）
EOF

# ----- 7) 打包 -----
[[ -z "$OUTPUT" ]] && OUTPUT="${DIST_DIR}/${PKG_NAME}.tar.gz"
log "[7/7] 制作压缩包：${OUTPUT}"
tar -C "${STAGE}" -czf "${OUTPUT}" "${PKG_NAME}"
SHA256="$(sha256sum "${OUTPUT}" | awk '{print $1}')"
SIZE="$(du -h "${OUTPUT}" | cut -f1)"
ok "打包完成：${OUTPUT}  (${SIZE}, sha256=${SHA256})"

rm -rf "${STAGE}"

cat <<EOF

==== 制作完成 ====
压缩包: ${OUTPUT}
大小  : ${SIZE}
SHA256: ${SHA256}

分发到目标机后：
    tar xzf $(basename "${OUTPUT}") && cd ${PKG_NAME}
    sudo bash INSTALL.sh [--ssl-domain pe.example.com | --ssl-ip]

EOF
