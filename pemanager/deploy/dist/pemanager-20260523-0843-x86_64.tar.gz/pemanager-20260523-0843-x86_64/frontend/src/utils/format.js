/**
 * 通用格式化工具。
 *
 * 时间统一展示策略：
 * - 后端 DRF 已经按 ISO 8601 + Asia/Shanghai 偏移（+08:00）输出，前端拿到的字符串
 *   形如 `2026-05-21T23:03:53+0800`。
 * - 这里始终按 Asia/Shanghai 时区渲染，避免不同浏览器本地时区带来不一致。
 */

const SH_FORMATTER = new Intl.DateTimeFormat('zh-CN', {
  year: 'numeric',
  month: '2-digit',
  day: '2-digit',
  hour: '2-digit',
  minute: '2-digit',
  second: '2-digit',
  hour12: false,
  timeZone: 'Asia/Shanghai',
})

function _parts(d) {
  const out = {}
  for (const p of SH_FORMATTER.formatToParts(d)) out[p.type] = p.value
  return out
}

/** YYYY-MM-DD HH:mm:ss (Asia/Shanghai) */
export function formatDateTime(value) {
  if (value === null || value === undefined || value === '') return '—'
  const d = value instanceof Date ? value : new Date(value)
  if (Number.isNaN(d.getTime())) return String(value)
  const p = _parts(d)
  return `${p.year}-${p.month}-${p.day} ${p.hour}:${p.minute}:${p.second}`
}

/** YYYY-MM-DD HH:mm:ss UTC+8（带尾标） */
export function formatDateTimeTz(value) {
  const s = formatDateTime(value)
  return s === '—' ? '—' : `${s} UTC+8`
}

/** YYYY-MM-DD (Asia/Shanghai) */
export function formatDate(value) {
  if (value === null || value === undefined || value === '') return '—'
  const d = value instanceof Date ? value : new Date(value)
  if (Number.isNaN(d.getTime())) return String(value)
  const p = _parts(d)
  return `${p.year}-${p.month}-${p.day}`
}

/** 友好相对时间：3 秒前 / 12 分钟前 / 2 小时前 / 5 天前 / 2026-05-21 */
export function formatRelative(value) {
  if (!value) return ''
  const d = value instanceof Date ? value : new Date(value)
  if (Number.isNaN(d.getTime())) return String(value)
  const diff = (Date.now() - d.getTime()) / 1000
  if (diff < 5) return '刚刚'
  if (diff < 60) return `${Math.floor(diff)} 秒前`
  if (diff < 3600) return `${Math.floor(diff / 60)} 分钟前`
  if (diff < 86400) return `${Math.floor(diff / 3600)} 小时前`
  if (diff < 86400 * 30) return `${Math.floor(diff / 86400)} 天前`
  return formatDate(d)
}

/** 字节友好展示 */
export function formatBytes(n) {
  if (n === null || n === undefined || Number.isNaN(Number(n))) return '—'
  const v = Number(n)
  if (v < 1024) return `${v} B`
  if (v < 1024 ** 2) return `${(v / 1024).toFixed(2)} KB`
  if (v < 1024 ** 3) return `${(v / 1024 ** 2).toFixed(2)} MB`
  if (v < 1024 ** 4) return `${(v / 1024 ** 3).toFixed(2)} GB`
  return `${(v / 1024 ** 4).toFixed(2)} TB`
}

/** 把任意可能不是字符串的值安全转字符串，便于 el-input 等绑定 */
export function asString(v) {
  if (v === null || v === undefined) return ''
  return String(v)
}

// =================== 数值精度统一：保留 2 位小数 ===================

const _DASH = '—'

/** 通用数值 toFixed(2)，空值显示 — */
export function fixed2(v) {
  if (v === null || v === undefined || v === '' || Number.isNaN(Number(v))) return _DASH
  return Number(v).toFixed(2)
}

/** bps -> 自动选档显示（Kbps/Mbps/Gbps），保留 2 位小数 */
export function formatBps(bps) {
  if (bps === null || bps === undefined || Number.isNaN(Number(bps))) return _DASH
  const v = Number(bps)
  if (v < 1e3) return `${v.toFixed(2)} bps`
  if (v < 1e6) return `${(v / 1e3).toFixed(2)} Kbps`
  if (v < 1e9) return `${(v / 1e6).toFixed(2)} Mbps`
  return `${(v / 1e9).toFixed(2)} Gbps`
}

/** bps -> Mbps（始终），保留 2 位小数 */
export function bpsToMbps(bps) {
  if (bps === null || bps === undefined || Number.isNaN(Number(bps))) return _DASH
  return (Number(bps) / 1e6).toFixed(2)
}

/** 丢包率 / 利用率 等百分比值，保留 2 位小数（不带 %） */
export function formatPct(v) {
  return fixed2(v)
}

/** RTT 毫秒，保留 2 位小数（不带 ms） */
export function formatMs(v) {
  return fixed2(v)
}
