<script setup>
import { computed, nextTick, onMounted, onUnmounted, reactive, ref, watch } from 'vue'
import { ElMessage } from 'element-plus'
import { Aim, Promotion, RefreshRight, VideoPlay, VideoPause } from '@element-plus/icons-vue'
import { operationApi } from '../../api/operationApi'
import { interfaceApi } from '../../api/interfaceApi'
import EChart from '../../components/EChart.vue'
import PageHeader from '../../components/PageHeader.vue'
import { fixed2 } from '../../utils/format'

const ASYNC_THRESHOLD = 10

const tab = ref('ping')
const ifaces = ref([])

async function loadIfaces() {
  try {
    const { data } = await interfaceApi.liveInventory()
    ifaces.value = data.interfaces || []
  } catch {
    ifaces.value = []
  }
}

// ---- 把每个接口的 IPv4/IPv6 地址展开成「源 IP」下拉项 ----
// label: "10.0.0.1 (ens18 ipv4)"  value: "10.0.0.1"
// 同时把接口名也作为可选项（label: "ens18 (整个接口)"  value: "ens18"）
const sourceOptions = computed(() => {
  const opts = []
  for (const i of ifaces.value || []) {
    opts.push({
      value: i.ifname,
      label: `${i.ifname} (整个接口)`,
      kind: 'iface',
      ifname: i.ifname,
    })
    for (const a of i.addresses || []) {
      const ip = a.local || a.address
      if (!ip) continue
      const fam = a.family || (ip.includes(':') ? 'inet6' : 'inet')
      const famShort = fam === 'inet6' ? 'ipv6' : 'ipv4'
      opts.push({
        value: ip,
        label: `${ip} (${i.ifname} ${famShort})`,
        kind: 'ip',
        ifname: i.ifname,
        family: famShort,
      })
    }
  }
  return opts
})

// ---- 通用：自动判断 sync / async 的执行 ----
async function runDiag(kind, address, count, source) {
  const fn = kind === 'mtr' ? operationApi.mtr : operationApi.ping
  return await fn({ address, count, source: source || undefined })
}

async function pollJob(id, onTick) {
  for (let i = 0; i < 600; i += 1) {
    const j = await operationApi.getJob(id)
    onTick?.(j)
    if (j.status === 'succeeded' || j.status === 'failed' || j.status === 'cancelled') return j
    await new Promise((r) => setTimeout(r, 1000))
  }
  return { status: 'timeout' }
}

// ===================== Ping =====================
const pingForm = reactive({ address: '', count: 5, source: '' })
const pingResult = ref(null)
const pingJob = ref(null)
const pingLoading = ref(false)

async function doPing() {
  if (!pingForm.address) {
    ElMessage.warning('请输入地址')
    return
  }
  pingLoading.value = true
  pingResult.value = null
  pingJob.value = null
  try {
    const resp = await runDiag('ping', pingForm.address, pingForm.count, pingForm.source)
    if (resp?.async && resp?.job) {
      pingJob.value = resp.job
      ElMessage.success(`已提交后台任务（${pingForm.count} 个包），后台运行中…`)
      const final = await pollJob(resp.job.id, (j) => (pingJob.value = j))
      pingJob.value = final
      if (final.status === 'succeeded') {
        pingResult.value = final.result
        ElMessage.success(`Ping 完成 (${final.duration_ms} ms)`)
      } else {
        ElMessage.error(`Ping 失败：${final.error || final.status}`)
      }
    } else {
      pingResult.value = resp
    }
  } catch (e) {
    ElMessage.error(e?.response?.data?.detail || e.message || '请求失败')
  } finally {
    pingLoading.value = false
  }
}

// ===================== MTR =====================
const mtrForm = reactive({ address: '', count: 5, source: '' })
const mtrResult = ref(null)
const mtrJob = ref(null)
const mtrLoading = ref(false)

async function doMtr() {
  if (!mtrForm.address) {
    ElMessage.warning('请输入地址')
    return
  }
  mtrLoading.value = true
  mtrResult.value = null
  mtrJob.value = null
  try {
    const resp = await runDiag('mtr', mtrForm.address, mtrForm.count, mtrForm.source)
    if (resp?.async && resp?.job) {
      mtrJob.value = resp.job
      ElMessage.success(`已提交后台任务（${mtrForm.count} 个包），后台运行中…`)
      const final = await pollJob(resp.job.id, (j) => (mtrJob.value = j))
      mtrJob.value = final
      if (final.status === 'succeeded') {
        mtrResult.value = final.result
        ElMessage.success(`MTR 完成 (${final.duration_ms} ms)`)
      } else {
        ElMessage.error(`MTR 失败：${final.error || final.status}`)
      }
    } else {
      mtrResult.value = resp
    }
  } catch (e) {
    ElMessage.error(e?.response?.data?.detail || e.message || '请求失败')
  } finally {
    mtrLoading.value = false
  }
}

// ===================== 接口实时流量 =====================
const trafficForm = reactive({ interface: '', window_sec: 1 })
const trafficLive = ref(null)
const trafficSeries = ref([]) // [{ ts, rx_mbps, tx_mbps }]
const trafficRunning = ref(false)
const MAX_POINTS = 240 // 约 4 分钟（2s/次）
let trafficTimer = null

const chartRef = ref(null)

async function trafficOnce() {
  try {
    trafficLive.value = await operationApi.trafficLive({ ...trafficForm })
    if (trafficLive.value?.ok) {
      const point = {
        ts: new Date().toISOString(),
        rx_mbps: (trafficLive.value.rx_bps || 0) / 1e6,
        tx_mbps: (trafficLive.value.tx_bps || 0) / 1e6,
      }
      trafficSeries.value.push(point)
      if (trafficSeries.value.length > MAX_POINTS) trafficSeries.value.shift()
    }
  } catch {
    /* 单次失败不弹错，下一轮重试 */
  }
}
function startTraffic() {
  if (!trafficForm.interface) {
    ElMessage.warning('请选择接口')
    return
  }
  trafficRunning.value = true
  trafficSeries.value = []
  trafficOnce()
  trafficTimer = setInterval(trafficOnce, 2000)
}
function stopTraffic() {
  trafficRunning.value = false
  if (trafficTimer) {
    clearInterval(trafficTimer)
    trafficTimer = null
  }
}

const trafficOption = computed(() => ({
  grid: { left: 56, right: 24, top: 32, bottom: 36, containLabel: true },
  legend: { data: ['RX Mbps', 'TX Mbps'], top: 0 },
  tooltip: {
    trigger: 'axis',
    axisPointer: { type: 'cross' },
    valueFormatter: (v) => (v === null || v === undefined ? '—' : Number(v).toFixed(2)),
  },
  xAxis: {
    type: 'time',
    splitLine: { show: true },
  },
  yAxis: {
    type: 'value',
    name: 'Mbps',
    min: 0,
    axisLabel: { formatter: (v) => Number(v).toFixed(2) },
  },
  series: [
    {
      name: 'RX Mbps',
      type: 'line',
      smooth: true,
      showSymbol: false,
      areaStyle: { opacity: 0.12 },
      data: trafficSeries.value.map((p) => [p.ts, p.rx_mbps]),
    },
    {
      name: 'TX Mbps',
      type: 'line',
      smooth: true,
      showSymbol: false,
      areaStyle: { opacity: 0.12 },
      data: trafficSeries.value.map((p) => [p.ts, p.tx_mbps]),
    },
  ],
}))

// 切到「接口流量」tab 后，EChart 父容器宽度变正常，主动 resize 一次
watch(tab, async (v) => {
  if (v === 'traffic') {
    await nextTick()
    chartRef.value?.resize?.()
    // 切换瞬间和 50ms 后各试一次，覆盖 transition
    setTimeout(() => chartRef.value?.resize?.(), 80)
  }
})

onUnmounted(() => stopTraffic())
onMounted(loadIfaces)
</script>

<template>
  <div class="page">
    <PageHeader
      title="诊断工具"
      description="ping / mtr 可指定源 IP；超过 10 个包自动后台运行；接口实时流量按时间滚动覆盖"
      :icon="Aim"
    />
    <el-tabs v-model="tab" type="border-card">
      <!-- ============================= Ping ============================= -->
      <el-tab-pane label="Ping" name="ping">
        <div class="row">
          <el-input v-model="pingForm.address" placeholder="目标 IP/主机名" style="width: 240px" />
          <el-input-number v-model="pingForm.count" :min="1" :max="1000" :step="1" />
          <el-select
            v-model="pingForm.source"
            placeholder="源 IP / 接口（可选）"
            clearable
            filterable
            allow-create
            style="width: 280px"
          >
            <el-option
              v-for="o in sourceOptions"
              :key="`${o.value}-${o.label}`"
              :label="o.label"
              :value="o.value"
            />
          </el-select>
          <el-button type="primary" :icon="Promotion" :loading="pingLoading" @click="doPing">
            Ping
          </el-button>
          <el-tag v-if="pingForm.count > ASYNC_THRESHOLD" type="warning" size="small">
            count &gt; {{ ASYNC_THRESHOLD }} → 后台执行
          </el-tag>
        </div>

        <!-- 异步任务进度 -->
        <el-alert
          v-if="pingJob && ['queued','running'].includes(pingJob.status)"
          :title="`后台任务运行中：${pingJob.kind} ${pingJob.address} (count=${pingJob.count})`"
          :description="`任务 ID ${pingJob.id} · 状态 ${pingJob.status}`"
          type="info"
          show-icon
          :closable="false"
          style="margin-top:10px"
        >
          <template #default>
            <el-progress :percentage="pingJob.status === 'queued' ? 5 : 60" :show-text="false" />
          </template>
        </el-alert>

        <el-descriptions v-if="pingResult" :column="3" border size="small" style="margin-top: 10px">
          <el-descriptions-item label="发送 / 接收">{{ pingResult.packets_sent }} / {{ pingResult.packets_recv }}</el-descriptions-item>
          <el-descriptions-item label="丢包率(%)">{{ fixed2(pingResult.loss_pct) }}</el-descriptions-item>
          <el-descriptions-item label="RTT min/avg/max(ms)">
            {{ fixed2(pingResult.rtt_min_ms) }} / {{ fixed2(pingResult.rtt_avg_ms) }} / {{ fixed2(pingResult.rtt_max_ms) }}
          </el-descriptions-item>
        </el-descriptions>
        <pre v-if="pingResult?.stdout" class="raw">{{ pingResult.stdout }}</pre>
      </el-tab-pane>

      <!-- ============================= MTR ============================= -->
      <el-tab-pane label="MTR" name="mtr">
        <div class="row">
          <el-input v-model="mtrForm.address" placeholder="目标 IP/主机名" style="width: 240px" />
          <el-input-number v-model="mtrForm.count" :min="1" :max="200" :step="1" />
          <el-select
            v-model="mtrForm.source"
            placeholder="源 IP / 接口（可选）"
            clearable
            filterable
            allow-create
            style="width: 280px"
          >
            <el-option
              v-for="o in sourceOptions"
              :key="`${o.value}-${o.label}`"
              :label="o.label"
              :value="o.value"
            />
          </el-select>
          <el-button type="primary" :icon="Promotion" :loading="mtrLoading" @click="doMtr">
            MTR
          </el-button>
          <el-tag v-if="mtrForm.count > ASYNC_THRESHOLD" type="warning" size="small">
            count &gt; {{ ASYNC_THRESHOLD }} → 后台执行
          </el-tag>
        </div>

        <el-alert
          v-if="mtrJob && ['queued','running'].includes(mtrJob.status)"
          :title="`后台任务运行中：${mtrJob.kind} ${mtrJob.address} (count=${mtrJob.count})`"
          :description="`任务 ID ${mtrJob.id} · 状态 ${mtrJob.status}`"
          type="info"
          show-icon
          :closable="false"
          style="margin-top:10px"
        >
          <template #default>
            <el-progress :percentage="mtrJob.status === 'queued' ? 5 : 60" :show-text="false" />
          </template>
        </el-alert>

        <el-table v-if="mtrResult?.hops?.length" :data="mtrResult.hops" border size="small" style="margin-top: 10px">
          <el-table-column prop="count" label="#" width="50" />
          <el-table-column prop="host" label="hop" min-width="180" />
          <el-table-column label="loss%" width="80">
            <template #default="{ row }">{{ fixed2(row.loss_pct) }}</template>
          </el-table-column>
          <el-table-column prop="snt" label="snt" width="60" />
          <el-table-column label="last" width="80">
            <template #default="{ row }">{{ fixed2(row.last_ms) }}</template>
          </el-table-column>
          <el-table-column label="avg" width="80">
            <template #default="{ row }">{{ fixed2(row.avg_ms) }}</template>
          </el-table-column>
          <el-table-column label="best" width="80">
            <template #default="{ row }">{{ fixed2(row.best_ms) }}</template>
          </el-table-column>
          <el-table-column label="worst" width="80">
            <template #default="{ row }">{{ fixed2(row.worst_ms) }}</template>
          </el-table-column>
          <el-table-column label="stdev" width="80">
            <template #default="{ row }">{{ fixed2(row.stdev_ms) }}</template>
          </el-table-column>
        </el-table>
        <pre v-else-if="mtrResult?.raw" class="raw">{{ mtrResult.raw }}</pre>
      </el-tab-pane>

      <!-- ============================= 接口流量 ============================= -->
      <el-tab-pane label="接口流量 (实时)" name="traffic">
        <div class="row">
          <el-select
            v-model="trafficForm.interface"
            filterable
            placeholder="选择接口"
            style="width: 220px"
          >
            <el-option v-for="i in ifaces" :key="i.ifname" :label="`${i.ifname} (${i.kind})`" :value="i.ifname" />
          </el-select>
          <el-input-number v-model="trafficForm.window_sec" :min="0.5" :max="5" :step="0.5" />
          <el-button v-if="!trafficRunning" type="primary" :icon="VideoPlay" @click="startTraffic">开始</el-button>
          <el-button v-else type="danger" :icon="VideoPause" @click="stopTraffic">停止</el-button>
          <el-button :icon="RefreshRight" plain :disabled="!trafficSeries.length" @click="trafficSeries = []">
            清空图表
          </el-button>
          <small class="muted">最近 {{ trafficSeries.length }} / {{ MAX_POINTS }} 点</small>
        </div>

        <el-descriptions v-if="trafficLive?.ok" :column="3" border size="small" style="margin-top: 10px">
          <el-descriptions-item label="窗口(s)">{{ fixed2(trafficLive.window_sec) }}</el-descriptions-item>
          <el-descriptions-item label="RX Mbps">{{ fixed2((trafficLive.rx_bps || 0) / 1e6) }}</el-descriptions-item>
          <el-descriptions-item label="TX Mbps">{{ fixed2((trafficLive.tx_bps || 0) / 1e6) }}</el-descriptions-item>
          <el-descriptions-item label="RX 累计字节">{{ trafficLive.rx_bytes_total }}</el-descriptions-item>
          <el-descriptions-item label="TX 累计字节">{{ trafficLive.tx_bytes_total }}</el-descriptions-item>
          <el-descriptions-item label="RX/TX 累计包">{{ trafficLive.rx_packets_total }} / {{ trafficLive.tx_packets_total }}</el-descriptions-item>
        </el-descriptions>

        <!-- 图表容器：full-width + 固定 360 高度 -->
        <div class="chart-wrap">
          <EChart ref="chartRef" :option="trafficOption" :height="360" />
        </div>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<style scoped>
.page { display: flex; flex-direction: column; gap: 12px; }
.row { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }
.raw { font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; font-size: 12px; background: var(--el-fill-color-light); padding: 10px; border-radius: 4px; overflow:auto; max-height: 360px; white-space: pre-wrap; }
.muted { color: var(--el-text-color-secondary); }
.chart-wrap {
  width: 100%;
  margin-top: 12px;
  background: var(--el-bg-color);
  border: 1px solid var(--el-border-color-lighter);
  border-radius: 4px;
  padding: 4px;
  box-sizing: border-box;
}
</style>
