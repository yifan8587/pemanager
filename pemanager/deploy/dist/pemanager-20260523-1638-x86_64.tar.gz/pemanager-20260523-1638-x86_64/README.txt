PE Manager 离线部署包
=====================

快速开始：
    tar xzf pemanager-20260523-1638-x86_64.tar.gz
    cd pemanager-20260523-1638-x86_64
    sudo bash INSTALL.sh                                  # HTTP 一键部署
    sudo bash INSTALL.sh --ssl-domain pe.example.com      # 带 Let's Encrypt 证书
    sudo bash INSTALL.sh --ssl-ip                         # 自签名（IP 部署）
    sudo bash INSTALL.sh --offline                        # 完全离线（需打包时 --with-debs/--with-wheels/--with-frontend）

详细文档：
    deploy/setup.md    - 环境检查
    deploy/deploy.md   - 部署与升级
    deploy/ssl.md      - HTTPS 启用
    deploy/package.md  - 打包说明
    deploy/API.md      - API 文档

部署后默认登录：
    URL：   http(s)://<主机/域名>/
    账号：  admin / admin123（首次登录请改密）
